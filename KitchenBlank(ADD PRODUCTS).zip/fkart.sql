-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 28, 2025 at 06:13 PM
-- Server version: 5.6.38
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fkart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `created_at`) VALUES
(1, 'tanay', '$2y$10$s.zKC3Y4nQyWkEnSPYNFS.gsUXyPk3CS/YUcnl7g6DU2Hnlaf71Sq', '2025-05-28 10:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `banner_img` varchar(255) NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `banner_img`, `update_date`) VALUES
(1, '683698b86a332_67f67b72432bb_6772c262d21f5_FK_banner1.jpg', '2025-05-28 10:31:44'),
(2, '683698c2757ce_6807c3bfae338_banner-17-04-2025-1744858143-banner-10-04-2025-1744234896-IMG_8470.jpg', '2025-05-28 10:31:54'),
(3, '68372fe5045d2_6826a85ee84c9_bn3.jpg', '2025-05-28 21:16:45'),
(4, '68372fed994fd_6826a8575d80e_bn2.jpg', '2025-05-28 21:16:53'),
(5, '68372ff910858_6826a85117464_bn1.jpg', '2025-05-28 21:17:05');

-- --------------------------------------------------------

--
-- Table structure for table `button_control`
--

CREATE TABLE `button_control` (
  `id` int(11) NOT NULL DEFAULT '1',
  `phonepe` tinyint(1) NOT NULL DEFAULT '0',
  `gpay` tinyint(1) NOT NULL DEFAULT '0',
  `paytm` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `button_control`
--

INSERT INTO `button_control` (`id`, `phonepe`, `gpay`, `paytm`) VALUES
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `mrp` decimal(10,2) NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `product_details` text,
  `first_image` varchar(255) DEFAULT NULL,
  `slide1` varchar(255) DEFAULT NULL,
  `slide2` varchar(255) DEFAULT NULL,
  `slide3` varchar(255) DEFAULT NULL,
  `slide4` varchar(255) DEFAULT NULL,
  `slide5` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `title`, `mrp`, `selling_price`, `product_details`, `first_image`, `slide1`, `slide2`, `slide3`, `slide4`, `slide5`, `created_at`) VALUES
(3, 'Little Mermaid Coffee Mug', 1299.00, 290.00, 'Little Mermaid Coffee Mug', '192.jpg', '192.jpg', '', '', '', '', '2025-05-28 07:10:21'),
(4, 'InstaCuppa Portable Blender Bottle | Long Lasting 6000 mAh Battery with Fast Charging | LED Display for Battery Status & 40-Second Blend Timer | Sipper Lid & Detachable Bottom Cap | 230 Watts, 600 ML', 4950.00, 399.00, 'InstaCuppa Portable Blender Bottle | Long Lasting 6000 mAh Battery with Fast Charging | LED Display for Battery Status & 40-Second Blend Timer | Sipper Lid & Detachable Bottom Cap | 230 Watts, 600 ML', '1748418034_BLenderBottleV3_7_1080x.jpg', 'BLenderBottleV3_4_1080x.jpg', 'BLenderBottleV3_3_1080x.jpg', 'BLenderBottleV3_6_1080x.jpg', '1748418034_BLenderBottleV3_5_1080x.jpg', 'BLenderBottleV3_6_1080x.jpg', '2025-05-28 07:21:43'),
(5, 'Nutri-blend Spring Mixer Grinder Blender & Smoothie Maker | 500W | 22000 RPM | 100% Copper Motor | 2 Unbreakable Jars | SS Blades | 2 Year Warranty | Recipe book by Chef Sanjeev Kapoor | Yellow', 8999.00, 290.00, 'Nutri-blend Spring Mixer Grinder Blender & Smoothie Maker | 500W | 22000 RPM | 100% Copper Motor | 2 Unbreakable Jars | SS Blades | 2 Year Warranty | Recipe book by Chef Sanjeev Kapoor | Yellow', 'NB-Spring.jpg', 'Nutri-blend-Spring-5_8ce3dba2-42f4-4c83-bdde-5b732a57fd64.jpg', 'Nutri-blend-Spring-6_f685451e-3d7e-46f2-8412-c6932852b80b.jpg', 'Nutri-blend-Spring-2_623d6f66-d030-459b-80b9-5af5f44fdfe4.jpg', 'Nutri-blend-Spring-3.jpg', '', '2025-05-28 07:43:53'),
(6, 'Nutri-blend Storm 1200W | 100% Copper Motor | Sharp 6-wing Stainless Steel Blade | Masalas, Chutney, Nuts, Crush Ice | 2 Jars | 22000 RPM | Sipper Attachment | 2 Year Warranty', 5999.00, 345.00, '<ul><li>Nutri-blend Storm 1200W | 100% Copper Motor | Sharp 6-wing Stainless Steel Blade | Masalas, Chutney, Nuts, Crush Ice | 2 Jars | 22000 RPM | Sipper Attachment | 2 Year Warranty</li></ul>', '63154914-Nutriblend-Storm-2Jar_Sipper-Jar-Black.jpg', '6805550.jpg', '6805551.jpg', '6805552.jpg', '6805553.jpg', '', '2025-05-28 08:19:23'),
(7, 'Ceramide Casserole Cookware Set', 8999.00, 299.00, '<ul><li>Ceramide Casserole Cookware Set</li></ul>', 'Wonderchef_Ceramide_Casserole_Set_-_Wonderchef-6798749.jpg', 'Cookware_Wonderchef_8904214707712-6798744.jpg', '', '', '', '', '2025-05-28 08:22:57'),
(8, 'Butterfly Smart Glass 4 Stove Burner', 4999.00, 367.00, '<ul><li>Butterfly Smart Glass 4 Stove Burner</li></ul>', '715J6iRpfOL._SX679_.jpg', '71lqdkFvvZL._SX679_.jpg', '71QSHUT6tRL._SX679_.jpg', '71yCOdUgsEL._SX679_.jpg', '', '', '2025-05-28 08:31:11'),
(9, 'Bandhan Non-stick Cookware 3 Pcs.Set | Dosa Tawa,Kadhai and Lid | 100% PFOA free Coating | Pure Grade Virgin Aluminium | Compatible with Multiple Cooktops | Red and Purple | 2 Year Warranty', 3599.00, 359.00, '<ul><li>Bandhan Non-stick Cookware 3 Pcs.Set | Dosa Tawa,Kadhai and Lid | 100% PFOA free Coating | Pure Grade Virgin Aluminium | Compatible with Multiple Cooktops | Red and Purple | 2 Year Warranty</li></ul>', '6797247.jpg', '6797249.jpg', '6797251.jpg', '6797253.jpg', '6797255.jpg', '', '2025-05-28 08:35:31'),
(10, 'Food52 X Kobenstyle Casserole', 4999.00, 339.00, '<ul><li>Food52 X Kobenstyle Casserole</li></ul>', '197 (1).jpg', '197.jpg', '197 (1).jpg', '', '', '', '2025-05-28 08:39:06'),
(11, 'Insulated Sipper Flask with Straw', 1999.00, 182.00, '<ul><li>Insulated Sipper Flask with Straw</li></ul>', '20250527_111854_0000.png', '', '', '', '', '', '2025-05-28 08:42:42'),
(12, 'Cast Iron Combo - Set of 3 - Kadhai 10\" inch + Paniyaram 12 cavities + Dosa Tawa 12\" inch', 1999.00, 287.00, '<ul><li>Cast Iron Combo - Set of 3 - Kadhai 10\" inch + Paniyaram 12 cavities + Dosa Tawa 12\" inch</li></ul>', 'SET_of_3.jpg', 'COMBO-kadhai-and--PANIYARAM-and-tawa_1.jpg', 'castiron04.jpeg', 'kadhai2_afa0dc6e-6a0d-4bbc-9e7d-5b5123a37788.jpeg', 'panniyaram05_8fee5309-05f3-4afc-a9c7-fd1620501b04.jpeg', '', '2025-05-28 08:52:00'),
(13, 'Dry Iron Cruze | 1000W | Quick Heating | Non-Stick Coated Sole Plate | Light and Compact Design | Temperature Control Dial | 1 Year Warranty', 2999.00, 292.00, '<ul><li>Dry Iron Cruze | 1000W | Quick Heating | Non-Stick Coated Sole Plate | Light and Compact Design | Temperature Control Dial | 1 Year Warranty</li></ul>', '6799830.jpg', '6799831.jpg', '6799832.jpg', '6799833.jpg', '6799834.jpg', '', '2025-05-28 08:54:23'),
(14, 'Woven Gemini Dry Fruits Box', 3999.00, 359.00, '<ul><li>Woven Gemini Dry Fruits Box</li></ul>', '187.jpg', '187.jpg', '187.jpg', '', '', '', '2025-05-28 08:56:12'),
(15, 'Marine Blue Non Stick Cookware Set - 14 Pc', 8199.00, 394.00, '<ul><li>Marine Blue Non Stick Cookware Set - 14 Pc</li></ul>', '108.jpg', '108.jpg', '108.jpg', '', '', '', '2025-05-28 09:01:07'),
(16, 'G Lamp with Speaker, Clock and Wireless Charger', 5599.00, 227.00, '<ul><li>G Lamp with Speaker, Clock and Wireless Charger</li></ul>', 'IMG_0688_21c35d21-b76b-48f2-b283-e7a4d8b5bc4a.jpg', '20250527_111251_0000.png', 'IMG_0785_4cd6d5d8-2467-4b58-bd5c-11bb39740d9c.jpg', '', '', '', '2025-05-28 09:05:43'),
(17, 'Acura Plus Mixer Grinder | 750W | 4 Jars for Blending, Dry Masala Grinding, Chutney Grinding, Smoothie | Sharp Stainless-Steel Blades | Grind Tough Ingredients | 5-Year Warranty on Motor', 5939.00, 293.00, '<ul><li>Acura Plus Mixer Grinder | 750W | 4 Jars for Blending, Dry Masala Grinding, Chutney Grinding, Smoothie | Sharp Stainless-Steel Blades | Grind Tough Ingredients | 5-Year Warranty on Motor</li></ul>', '6795410.jpg', '6795412.jpg', '6795414.jpg', '6795416.jpg', '6795418.jpg', '6795421.jpg', '2025-05-28 09:13:31'),
(18, 'Pure Source India Ceramic Pickle Jar With Lid - 5000 ML, 1 Piece, Ivory and Brown', 2999.00, 187.00, '<ul><li>Pure Source India Ceramic Pickle Jar With Lid - 5000 ML, 1 Piece, Ivory and Brown</li></ul>', '71dXRCxJKSL._AC_UF1000,1000_QL80_FMwebp_.jpg', '91bRUTFz4oL._AC_UF350,350_QL80_FMwebp_.jpg', '91rKSaX-hPL._AC_UF1000,1000_QL80_FMwebp_.jpg', '81Kin7LMNZL._AC_UF1000,1000_QL80_FMwebp_.jpg', '', '', '2025-05-28 09:17:38'),
(19, 'Kitchen Organiser - Pack Of 14 Pc', 1999.00, 389.00, '<ul><li>Kitchen Organiser - Pack Of 14 Pc</li></ul>', '193.jpg', '193.jpg', '193.jpg', '', '', '', '2025-05-28 09:20:42'),
(20, 'White Colour Villeroy and boch cafe mugs', 1599.00, 225.00, '<ul><li>White Colour Villeroy and boch cafe mugs</li></ul>', '186.jpg', '186.jpg', '186.jpg', '', '', '', '2025-05-28 09:22:58'),
(21, 'Regenta Full Fruit Juicer | Professional Cold Press | High Juice Yield | 240W | 55 RPM | Fine Strainer | All-in-1 Fruit & Vegetable Juicer | White | 2 Year Warranty', 5999.00, 401.00, '<ul><li>Regenta Full Fruit Juicer | Professional Cold Press | High Juice Yield | 240W | 55 RPM | Fine Strainer | All-in-1 Fruit & Vegetable Juicer | White | 2 Year Warranty</li></ul>', '6810537.jpg', '6810540.jpg', '6810544.jpg', '6810547.jpg', '6810556.jpg', '', '2025-05-28 09:25:50'),
(22, 'Dosa Tawa Non Stick with Nylon Scrubber', 799.00, 189.00, '<ul><li>Dosa Tawa Non Stick with Nylon Scrubber</li></ul>', '190.jpg', '190.jpg', '190.jpg', '190.jpg', '', '', '2025-05-28 09:28:16'),
(23, 'Digital Air Fryer', 15999.00, 679.00, '<ul><li>Digital Air Fryer</li></ul>', 'WhatsApp_Image_2024-12-14_at_20.09.47_9d8e25c8.jpg', 'image_2_aa834675-b15b-42b7-9611-ea72b5bf14a8.png', 'image_3_647c1bed-bf73-486e-b47a-9140df591040.png', 'B0C2Q5QD9L.PT05_fa0a79f4-9cc4-4d21-af3b-1963590ee220.jpg', '', '', '2025-05-28 09:31:58'),
(24, '3-Tier fruit bowl decoration set', 999.00, 179.00, '<ul><li>3-Tier fruit bowl decoration set</li></ul>', '188.jpg', '188.jpg', '188.jpg', '', '', '', '2025-05-28 09:36:03'),
(25, 'Premium Electric Kettle', 2499.00, 319.00, '<ul><li>Premium Electric Kettle</li></ul>', 'a_2_62feaaab-9bc7-4a09-a38b-9d5e570e9b97.jpg', 'b_2.jpg', 'c_2.jpg', 'd_2.jpg', '', '', '2025-05-28 09:39:14'),
(26, 'Prestige Svach 5L Cooker', 2200.00, 299.00, '<ul><li>Prestige Svach 5L Cooker</li></ul>', '713Kl1I0CyL._SL1500_.jpg', '61stfFZduNL._SL1000_ (1).jpg', '61d5WlFUjUL._SL1000_ (1).jpg', '61ZTSJHk9EL._SL1000_ (1).jpg', '61KhOczfHTL._SL1000_ (1).jpg', '', '2025-05-28 09:43:59'),
(27, 'Electric Contact Grill & Sandwich Maker |3-in-1 Appliance|1500 Watt|180 Degree Grilling|Cool Touch Handle|Auto Shut Off|LED Indicator|2 Year Warranty|Black & Silver', 8999.00, 409.00, '<ul><li>Electric Contact Grill & Sandwich Maker |3-in-1 Appliance|1500 Watt|180 Degree Grilling|Cool Touch Handle|Auto Shut Off|LED Indicator|2 Year Warranty|Black & Silver</li></ul>', '6814973.jpg', '6814976.jpg', '6814979.jpg', '6814982.jpg', '6814987.jpg', '', '2025-05-28 09:50:16'),
(28, 'Teivio 32 Pc Kitchen Set', 6200.00, 349.00, '<ul><li>Teivio 32 Pc Kitchen Set</li></ul>', '81uNog-p3vL._AC_SL1500_.jpg', '61TNyS7Nc+L._AC_SL1500_.jpg', '61UAfgVCieL._AC_SL1000_.jpg', '71+2Usp9jGL._AC_SL1500_.jpg', '71JxTAAhUaL._AC_SL1500_.jpg', '', '2025-05-28 10:02:22'),
(29, 'Wonderchef Renewed Magneto Blender | Smoothie & Juice Maker | World’s Safest with Magnetic Induction Tech | Variable Speed | Automatic with 60-sec auto-stop | Portable with Sipper Jar | 1-Year Warranty', 8999.00, 449.00, '<ul><li>Wonderchef Renewed Magneto Blender | Smoothie & Juice Maker | World’s Safest with Magnetic Induction Tech | Variable Speed | Automatic with 60-sec auto-stop | Portable with Sipper Jar | 1-Year Warranty</li></ul>', '6822776.jpg', '6822780.jpg', '6822781.jpg', '6822783.jpg', '6822785.jpg', '', '2025-05-28 10:08:04'),
(30, 'MARKWELL Plastic 3 in 1 Soap Pump Dispenser Dish Soap Liquid Dispenser Sponge Holder Dish Soap Pump Dispenser for Kitchen Sink Countertop Kitchen Bathroom (Multi-Color)', 999.00, 99.00, '<ul><li>MARKWELL Plastic 3 in 1 Soap Pump Dispenser Dish Soap Liquid Dispenser Sponge Holder Dish Soap Pump Dispenser for Kitchen Sink Countertop Kitchen Bathroom (Multi-Color)</li><ul>', '51geMcR5teL._AC_UF894,1000_QL80_FMwebp_.jpg', '51Wks-RfRkL._AC_UF350,350_QL80_FMwebp_.jpg', '515qvmzRTiL._AC_UF350,350_QL80_FMwebp_.jpg', '71lk2c4KAkL._AC_UF350,350_QL80_FMwebp_.jpg', '', '', '2025-05-28 10:12:29'),
(31, 'Classic White Colur Jug With Cup Set', 1799.00, 229.00, '<ul><li>Classic White Colur Jug With Cup Set</li></ul>', '189.jpg', '189.jpg', '189.jpg', '189.jpg', '', '', '2025-05-28 10:14:42'),
(32, 'Top 20 Kitchen Accesories - Combo', 4999.00, 297.00, '<ul><li>Top 20 Kitchen Accesories - Combo</li></ul>', '194.jpg', '194.jpg', '194.jpg', '194.jpg', '', '', '2025-05-28 10:17:11'),
(33, 'Flipkart Basic Non Stock Cookware', 2599.00, 348.00, '<ul><li>Flipkart Basic Non Stock Cookware</li></ul>', '71oZ1-QYomL._SX679_.jpg', '718EMFqgAbL._SX679_.jpg', '816KC3UA1FL._SX679_.jpg', '71X4XmjuYjS._SX679_.jpg', '71rfwme1s0S._SL1500_.jpg', '', '2025-05-28 10:26:03'),
(34, 'kitchen Stainless Steel Strainer cooking oil Sifter', 1099.00, 129.00, '<ul><li>kitchen Stainless Steel Strainer cooking oil Sifter</li></ul>', '195.jpg', '195.jpg', '195.jpg', '', '', '', '2025-05-28 10:27:56'),
(35, 'Wonderchef Renewed Valencia 4 Piece Kitchen Set | Fry Pan, Wok (without Lid), Dosa Tawa & Inner Lid Pressure Cooker', 7999.00, 459.00, '<ul><li>Wonderchef Renewed Valencia 4 Piece Kitchen Set | Fry Pan, Wok (without Lid), Dosa Tawa & Inner Lid Pressure Cooker</li></ul>', '6824295.jpg', '6824297.jpg', '', '', '', '', '2025-05-28 10:29:42'),
(36, 'Nutri-cup Portable Blender + Sippy Stainless Steel Bottle, Gift Combo, For Family and Friends, Gift for Diwali and Other Festivals, House Warming', 4999.00, 378.00, '<ul><li>Nutri-cup Portable Blender + Sippy Stainless Steel Bottle, Gift Combo, For Family and Friends, Gift for Diwali and Other Festivals, House Warming</li></ul>', '6805901.jpg', '6805902.jpg', '6805903.jpg', '6805904.jpg', '6805905.jpg', '', '2025-05-28 10:33:33'),
(37, 'LG 28L Convection Microwave Oven', 9235.00, 398.00, '<ul><li>LG 28L Convection Microwave Oven</ul></li>', '71uyOr3cKWL._SX679_.jpg', '81ol78qaqdL._SX679_.jpg', '81Ea-4KWiBL._SX679_.jpg', '81RV8ZcY2vL._SX679_.jpg', '81YfsJLJK9L._SX679_.jpg', '', '2025-05-28 10:37:58'),
(38, 'Prestige IRIS Plus 750W Mixer Grinder', 3999.00, 350.00, '<ul><li>Prestige IRIS Plus 750W Mixer Grinder</li></ul>', '61Ov3MaB8BL._SX679_.jpg', '61b02CToonL._SX679_.jpg', '617dnjoIDjL._SX679_.jpg', '617BJXmORxL._SX679_.jpg', '61fDq1MloJL._SX679_.jpg', '', '2025-05-28 10:44:35'),
(39, 'Crownstone Cast Iron Tawa with 2 Loops, 100% Pure Cast Iron, Pre Seasoned, Natural Nonstick, Free Spatula, 38cms, 2.1kgs', 2459.00, 278.00, '<ul><li>Crownstone Cast Iron Tawa with 2 Loops, 100% Pure Cast Iron, Pre Seasoned, Natural Nonstick, Free Spatula, 38cms, 2.1kgs</li></ul>', 'crownstone_cast_iron_kadai.jpg', 'Artboard3_426a7dd6-5efe-4d32-9db8-5d6beaf4792a.jpg', 'Artboard2.jpg', 'Artboard4.jpg', '', '', '2025-05-28 10:48:02');

-- --------------------------------------------------------

--
-- Table structure for table `upi`
--

CREATE TABLE `upi` (
  `id` int(11) NOT NULL DEFAULT '1',
  `all_upi` varchar(255) DEFAULT NULL,
  `paytm_upi` varchar(255) DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `upi`
--

INSERT INTO `upi` (`id`, `all_upi`, `paytm_upi`, `update_date`) VALUES
(1, 'tanay1609@fam', 'tanay1609@fam', '2025-05-28 07:01:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `button_control`
--
ALTER TABLE `button_control`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `upi`
--
ALTER TABLE `upi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
